package pages;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;

public class GetBalance {
    public static void getBalance() {
        String expectedCurrency = "usd";
        Response response = RestAssured
                .given()
                .baseUri("https://api.stripe.com")
                .basePath("/v1/balance")
                .header("Authorization", "Basic c2tfdGVzdF81MVA4UnFnMk1yWDBBSnVZa2VHQU5tNklIb3oxOHhLWU5nSEVGcUFiZlR5Zk92cjY3dkxRdGRuS1FtMU1KeWR1aHQwWnBvR1dZUmhZa0pnZmZiT1pUSkZtNTAwc3QKZHlnYlRTOg==")
                .when()
                .get();
        JsonPath path = new JsonPath(response.asString());
        String currency = path.getString("pending[0].currency");
        String amount = path.getString("pending[0].amount");
        int actualAmount = Integer.valueOf(amount);
        Assert.assertEquals(currency,expectedCurrency);
        if (actualAmount > 0)
        {
            System.out.println();
            System.out.println("Amount is : "+actualAmount);}
        else
        {
            System.out.println();
            System.out.println("Amount is : 0)");
        }
    }

}

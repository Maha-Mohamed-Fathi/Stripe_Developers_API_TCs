package pages;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;

public class CreateCharge {

    public static void createCharge() {
        String expectedAmount_authorized = "50";
        String expectedBrand = "visa";
        String expectedExp_month = "4";
        String expectedExp_year = "2025";
        Response response = RestAssured
                .given()
                .header("Authorization", "Basic c2tfdGVzdF81MVA4UnFnMk1yWDBBSnVZa2VHQU5tNklIb3oxOHhLWU5nSEVGcUFiZlR5Zk92cjY3dkxRdGRuS1FtMU1KeWR1aHQwWnBvR1dZUmhZa0pnZmZiT1pUSkZtNTAwc3QKZHlnYlRTOg==")
                .queryParam("amount", "50")
                .queryParam("currency", "usd")
                .queryParam("source", "tok_visa")
                .queryParam("description", "Test charge")
                .when()
                .post("https://api.stripe.com/v1/charges");
        JsonPath path = new JsonPath(response.asString());
        String amount_authorized = path.getString("payment_method_details.card.amount_authorized");
        Assert.assertEquals(amount_authorized, expectedAmount_authorized);
        String brand = path.getString("payment_method_details.card.brand");
        Assert.assertEquals(brand, expectedBrand);
        String exp_month = path.getString("payment_method_details.card.exp_month");
        Assert.assertEquals(exp_month, expectedExp_month);
        String exp_year = path.getString("payment_method_details.card.exp_year");
        Assert.assertEquals(exp_year, expectedExp_year);

    }
}

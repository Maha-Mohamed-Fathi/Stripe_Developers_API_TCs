package tests;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import pages.CreateCharge;
import pages.GetBalance;


public class Runner {


    public static void main(String[] args) {
        GetBalance getBalance = new GetBalance();
        CreateCharge createCharge = new CreateCharge();

        getBalance.getBalance();
        createCharge.createCharge();

    }
}